#include <iostream>
#include <string>
#include <vector>
using namespace std;


// EX06_01 Liang 12.2: Linear Search
template <typename T> //Using template to substitute list and key within the array
int linearSearch(const T list[], T key, int arraySize)
{
	for (int i = 0; i < arraySize; i++)
	{
		if (key == list[i]) // if the key is equal to the list array  
			return i; // then it returns i 
	}
	return -1; // RETURNS -1 
}

// EX06_02 Liang 12.4: Is Sorted?
template <typename M>
// Using a basic template to substitute the list
bool isSorted(const M list[], int arraySize)
{
	for (int i = 1; i < arraySize; i++)
	{
		if (list[i] < list[i - 1]) // If current element is smaller than previous, return false
		{
			cout << "False \n";
			return false; // RETURNS FALSE 
		}
		else
		{
			cout << "True \n"; // if the current element is larger that the previouys then returns true
			return true; // RETURNS TRUE
		}
	}
}

// EX06_04 Liang 12.20: Shuffle Vector Class
template <typename A>
// using a basic template to subsuitute
void shuffle(vector<A> &a)
{
	int size = a.size();
	A tempNums; // Implements placeholders for inputted numbers
	int randm = 0;
	for (int i = 0; i < size; i++)
	{
		randm = rand() % (i + 1);
		tempNums = a[i]; // Assigns the temporary number into an array
		a[i] = a[randm];
		a[randm] = tempNums; // Randomize the numbers
	}
}


int main()
{

	int arraySize = 5; // Implements size as 5
	int arrayT[5] = { 5, 9, 15, 16, 30 };
	double arrayM[5] = { 4.1, 3.2, 9.4, 2.5, 2.8 };
	string arrayA[5] = { "T", "M", "A","Q","Y" };
	string findStrg = "Y"; // Implements the string to "Y"

 // EX06_01 12.2: Linear Search
	linearSearch(arrayT, 3, arraySize); // Calls the int array
	linearSearch(arrayM, 2.2, arraySize); // Calls the double array
	linearSearch(arrayA, findStrg, arraySize); // Calls the string array

 // EX06_02 12.4: Is Sorted?
	isSorted(arrayT, arraySize); // Calls the int array
	isSorted(arrayM, arraySize); // Calls the double array
	isSorted(arrayA, arraySize); // Calls the string array

 // EX06_04 12.20: Shuffle Vector Class
	vector<int> v1(10); // Vector size hold 10 integers
	cout << "Please enter 10 integers: " << endl;
	for (int size = 0; size < 10; size++)
	{
		cin >> v1[size]; // Store the integers into places in size
	}
	cout << endl;

	shuffle(v1); // Shuffle the numbers
	cout << "Shuffled integers: " << endl;
	for (int size = 0; size < 10; size++)
	{
		cout << v1[size] << endl; // Makes sure that all places are filled and displayed
	}
	return 0;
}